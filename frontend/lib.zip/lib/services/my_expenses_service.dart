import 'dart:convert';
import 'package:http/http.dart' as http;

class PetSchedule {
  final String category;
  final int expense;
  final String description;
  final String date;
  final int scheduleId;

  PetSchedule({
    required this.category,
    required this.expense,
    required this.description,
    required this.date,
    required this.scheduleId,
  });

  factory PetSchedule.fromJson(Map<String, dynamic> json) {
    return PetSchedule(
      category: json['category'],
      expense: json['expense'],
      description: json['description'],
      date: json['date'],
      scheduleId: json['schedule_id'],
    );
  }
}

class Pet {
  final int petId;
  final String name;
  final String gender;
  final String type;
  final String birthdate;
  final String breed;
  final int weight;
  final String color;
  final List<PetSchedule> petSchedule;

  Pet({
    required this.petId,
    required this.name,
    required this.gender,
    required this.type,
    required this.birthdate,
    required this.breed,
    required this.weight,
    required this.color,
    required this.petSchedule,
  });

  factory Pet.fromJson(Map<String, dynamic> json) {
    var schedules = (json['petSchedule'] as List)
        .map((e) => PetSchedule.fromJson(e))
        .toList();

    return Pet(
      petId: json['petid'],
      name: json['name'],
      gender: json['gender'],
      type: json['type'],
      birthdate: json['birthdate'],
      breed: json['breed'],
      weight: json['weight'],
      color: json['color'],
      petSchedule: schedules,
    );
  }
}

class PetsResponse {
  final List<Pet> pets;
  final int totalExpense;

  PetsResponse({required this.pets, required this.totalExpense});

  factory PetsResponse.fromJson(Map<String, dynamic> json) {
    var pets = (json['pets'] as List).map((e) => Pet.fromJson(e)).toList();
    return PetsResponse(pets: pets, totalExpense: json['totalExpense']);
  }
}

class MyExpensesService {
  static const String baseUrl = 'http://localhost:8080/api/petschedules/user';

  Future<PetsResponse> fetchUserExpenses(int userId) async {
    final url = Uri.parse('$baseUrl/$userId');

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return PetsResponse.fromJson(jsonData);
    } else {
      throw Exception('Failed to load expenses');
    }
  }
}
