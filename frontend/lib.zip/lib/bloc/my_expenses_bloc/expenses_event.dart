abstract class ExpensesEvent {}

class LoadExpenses extends ExpensesEvent {}
